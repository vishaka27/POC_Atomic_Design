import React,{Component} from 'react';

//Select Tag
class SelectTag extends Component {
	render() {
		return (
			<select>
			{this.props.children}
			</select>
		)
	}
}

export default SelectTag;