import React, {Component} from 'react';

import Div from '../../components/Div';
import Header from '../Header';
import Item from '../Item';
import SideBar from '../SideBar';
import './homepage.css';



//HomePage Container
class HomePage extends Component {
	render() {
		return (
			<Div>
			<Header />
			<SideBar />
			<Div class="item-container">
			<Item src="../../images/hulk.jpg" linkname="Hulk" href="https://en.wikipedia.org/wiki/Hulk_(comics)" info="The Hulk is a fictional superhero "/>
			<Item src="../../images/hulk.jpg" linkname="Hulk" href="https://en.wikipedia.org/wiki/Hulk_(comics)" info="The Hulk is a fictional superhero "/>
			<Item src="../../images/hulk.jpg" linkname="Hulk" href="https://en.wikipedia.org/wiki/Hulk_(comics)" info="The Hulk is a fictional superhero "/>
			<Item src="../../images/hulk.jpg" linkname="Hulk" href="https://en.wikipedia.org/wiki/Hulk_(comics)" info="The Hulk is a fictional superhero "/>
			<Item src="../../images/hulk.jpg" linkname="Hulk" href="https://en.wikipedia.org/wiki/Hulk_(comics)" info="The Hulk is a fictional superhero "/>
			<Item src="../../images/hulk.jpg" linkname="Hulk" href="https://en.wikipedia.org/wiki/Hulk_(comics)" info="The Hulk is a fictional superhero "/>
			<Item src="../../images/hulk.jpg" linkname="Hulk" href="https://en.wikipedia.org/wiki/Hulk_(comics)" info="The Hulk is a fictional superhero "/>
			<Item src="../../images/hulk.jpg" linkname="Hulk" href="https://en.wikipedia.org/wiki/Hulk_(comics)" info="The Hulk is a fictional superhero "/>
			<Item src="../../images/hulk.jpg" linkname="Hulk" href="https://en.wikipedia.org/wiki/Hulk_(comics)" info="The Hulk is a fictional superhero "/>
			<Item src="../../images/hulk.jpg" linkname="Hulk" href="https://en.wikipedia.org/wiki/Hulk_(comics)" info="The Hulk is a fictional superhero "/>
			<Item src="../../images/hulk.jpg" linkname="Hulk" href="https://en.wikipedia.org/wiki/Hulk_(comics)" info="The Hulk is a fictional superhero "/>
			<Item src="../../images/hulk.jpg" linkname="Hulk" href="https://en.wikipedia.org/wiki/Hulk_(comics)" info="The Hulk is a fictional superhero "/>
			<Item src="../../images/hulk.jpg" linkname="Hulk" href="https://en.wikipedia.org/wiki/Hulk_(comics)" info="The Hulk is a fictional superhero "/>
			<Item src="../../images/hulk.jpg" linkname="Hulk" href="https://en.wikipedia.org/wiki/Hulk_(comics)" info="The Hulk is a fictional superhero "/>
			<Item src="../../images/hulk.jpg" linkname="Hulk" href="https://en.wikipedia.org/wiki/Hulk_(comics)" info="The Hulk is a fictional superhero "/>
			<Item src="../../images/hulk.jpg" linkname="Hulk" href="https://en.wikipedia.org/wiki/Hulk_(comics)" info="The Hulk is a fictional superhero "/>
			<Item src="../../images/hulk.jpg" linkname="Hulk" href="https://en.wikipedia.org/wiki/Hulk_(comics)" info="The Hulk is a fictional superhero "/>
			<Item src="../../images/hulk.jpg" linkname="Hulk" href="https://en.wikipedia.org/wiki/Hulk_(comics)" info="The Hulk is a fictional superhero "/>
			<Item src="../../images/hulk.jpg" linkname="Hulk" href="https://en.wikipedia.org/wiki/Hulk_(comics)" info="The Hulk is a fictional superhero "/>
			<Item src="../../images/hulk.jpg" linkname="Hulk" href="https://en.wikipedia.org/wiki/Hulk_(comics)" info="The Hulk is a fictional superhero "/>
			<Item src="../../images/hulk.jpg" linkname="Hulk" href="https://en.wikipedia.org/wiki/Hulk_(comics)" info="The Hulk is a fictional superhero "/>
			<Item src="../../images/hulk.jpg" linkname="Hulk" href="https://en.wikipedia.org/wiki/Hulk_(comics)" info="The Hulk is a fictional superhero "/>
			<Item src="../../images/hulk.jpg" linkname="Hulk" href="https://en.wikipedia.org/wiki/Hulk_(comics)" info="The Hulk is a fictional superhero "/>
			<Item src="../../images/hulk.jpg" linkname="Hulk" href="https://en.wikipedia.org/wiki/Hulk_(comics)" info="The Hulk is a fictional superhero "/>

			</Div>
			</Div>

		);
	}
}
export default HomePage;
