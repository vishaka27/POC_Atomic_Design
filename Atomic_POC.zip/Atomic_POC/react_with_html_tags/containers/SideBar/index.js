import React, {Component} from 'react';
import './sidebar.css';
import Img from '../../components/Img';
import SelectTag from '../../components/Select';
import OptionTag from '../../components/Option';
import Div from '../../components/Div';
import A from '../../components/A';
import Ul from '../../components/Ul';
import Li from '../../components/Li';



//SideBar Container
class SideBar extends Component {
	render() {
		return (
			<div className="sidebar-style">
			<div className="sideimage-style">
				<img src="../../images/gradient.jpg" alt="No image found" className="image-style-sidebar"/>
			<ul className="movie-list-style">
			<li>
			<a href="https://en.wikipedia.org/wiki/list_of_films_based_on_Marvel_Comics">MARVEL FILMS</a>
			</li>
			<li>
			<a href="https://en.wikipedia.org/wiki/list_of_Marvel_Comics_characters">MARVEL CHARACTERS
			</a>
			</li>
			<li>
			Search for Movies by Year
			</li>
			<li>
			<select>
				<option>1991-1995</option>
				<option>1996-2000</option>
				<option>2001-2005</option>
				<option>2006-2010</option>
				<option>2011-2015</option>
				<option>2016-Present</option>
			</select>
			</li>
			</ul>
			</div>
			</div>

			
			)
	}
}

export default SideBar;