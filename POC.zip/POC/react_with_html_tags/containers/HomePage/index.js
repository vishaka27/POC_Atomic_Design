import React, {Component} from 'react';
<<<<<<< HEAD
=======
import Div from '../../components/Div';
>>>>>>> e68a2edfdc9cd63496766847a1ad9eba1672fbb6
import Header from '../Header';
import Item from '../Item';
import SideBar from '../SideBar';
import './homepage.css';

<<<<<<< HEAD
class HomePage extends Component {
	render() {
		return (
			<div>
			<Header />
			<SideBar />
			<div className="item-container">
=======
//HomePage Container
class HomePage extends Component {
	render() {
		return (
			<Div>
			<Header />
			<SideBar />
			<Div class="item-container">
>>>>>>> e68a2edfdc9cd63496766847a1ad9eba1672fbb6
			<Item src="../../images/hulk.jpg" linkname="Hulk" href="https://en.wikipedia.org/wiki/Hulk_(comics)" info="The Hulk is a fictional superhero "/>
			<Item src="../../images/hulk.jpg" linkname="Hulk" href="https://en.wikipedia.org/wiki/Hulk_(comics)" info="The Hulk is a fictional superhero "/>
			<Item src="../../images/hulk.jpg" linkname="Hulk" href="https://en.wikipedia.org/wiki/Hulk_(comics)" info="The Hulk is a fictional superhero "/>
			<Item src="../../images/hulk.jpg" linkname="Hulk" href="https://en.wikipedia.org/wiki/Hulk_(comics)" info="The Hulk is a fictional superhero "/>
			<Item src="../../images/hulk.jpg" linkname="Hulk" href="https://en.wikipedia.org/wiki/Hulk_(comics)" info="The Hulk is a fictional superhero "/>
			<Item src="../../images/hulk.jpg" linkname="Hulk" href="https://en.wikipedia.org/wiki/Hulk_(comics)" info="The Hulk is a fictional superhero "/>
			<Item src="../../images/hulk.jpg" linkname="Hulk" href="https://en.wikipedia.org/wiki/Hulk_(comics)" info="The Hulk is a fictional superhero "/>
			<Item src="../../images/hulk.jpg" linkname="Hulk" href="https://en.wikipedia.org/wiki/Hulk_(comics)" info="The Hulk is a fictional superhero "/>
			<Item src="../../images/hulk.jpg" linkname="Hulk" href="https://en.wikipedia.org/wiki/Hulk_(comics)" info="The Hulk is a fictional superhero "/>
			<Item src="../../images/hulk.jpg" linkname="Hulk" href="https://en.wikipedia.org/wiki/Hulk_(comics)" info="The Hulk is a fictional superhero "/>
			<Item src="../../images/hulk.jpg" linkname="Hulk" href="https://en.wikipedia.org/wiki/Hulk_(comics)" info="The Hulk is a fictional superhero "/>
			<Item src="../../images/hulk.jpg" linkname="Hulk" href="https://en.wikipedia.org/wiki/Hulk_(comics)" info="The Hulk is a fictional superhero "/>
			<Item src="../../images/hulk.jpg" linkname="Hulk" href="https://en.wikipedia.org/wiki/Hulk_(comics)" info="The Hulk is a fictional superhero "/>
			<Item src="../../images/hulk.jpg" linkname="Hulk" href="https://en.wikipedia.org/wiki/Hulk_(comics)" info="The Hulk is a fictional superhero "/>
			<Item src="../../images/hulk.jpg" linkname="Hulk" href="https://en.wikipedia.org/wiki/Hulk_(comics)" info="The Hulk is a fictional superhero "/>
			<Item src="../../images/hulk.jpg" linkname="Hulk" href="https://en.wikipedia.org/wiki/Hulk_(comics)" info="The Hulk is a fictional superhero "/>
			<Item src="../../images/hulk.jpg" linkname="Hulk" href="https://en.wikipedia.org/wiki/Hulk_(comics)" info="The Hulk is a fictional superhero "/>
			<Item src="../../images/hulk.jpg" linkname="Hulk" href="https://en.wikipedia.org/wiki/Hulk_(comics)" info="The Hulk is a fictional superhero "/>
			<Item src="../../images/hulk.jpg" linkname="Hulk" href="https://en.wikipedia.org/wiki/Hulk_(comics)" info="The Hulk is a fictional superhero "/>
			<Item src="../../images/hulk.jpg" linkname="Hulk" href="https://en.wikipedia.org/wiki/Hulk_(comics)" info="The Hulk is a fictional superhero "/>
			<Item src="../../images/hulk.jpg" linkname="Hulk" href="https://en.wikipedia.org/wiki/Hulk_(comics)" info="The Hulk is a fictional superhero "/>
			<Item src="../../images/hulk.jpg" linkname="Hulk" href="https://en.wikipedia.org/wiki/Hulk_(comics)" info="The Hulk is a fictional superhero "/>
			<Item src="../../images/hulk.jpg" linkname="Hulk" href="https://en.wikipedia.org/wiki/Hulk_(comics)" info="The Hulk is a fictional superhero "/>
			<Item src="../../images/hulk.jpg" linkname="Hulk" href="https://en.wikipedia.org/wiki/Hulk_(comics)" info="The Hulk is a fictional superhero "/>
<<<<<<< HEAD
			</div>
			</div>
=======
			</Div>
			</Div>
>>>>>>> e68a2edfdc9cd63496766847a1ad9eba1672fbb6
		);
	}
}
export default HomePage;
